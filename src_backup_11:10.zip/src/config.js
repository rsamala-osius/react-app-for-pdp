export const config = {
    // apiUrl: 'http://localhost:3004',
     apiUrl: 'http://172.30.113.112:5000/api',
}

