import React, { Component } from 'react';
import Tiles from '../tile/tile-component';
import { Grid, Row } from 'react-bootstrap';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import {getItems} from '../../actions/search-list-actions';



class SearchFormComponent extends Component {
    constructor(props){
        super(props);
       // this.state = {items: this.props.items};
        this.props.getItems();
    }
    // static getDerivedStateFromProps(props, state){
    //     console.log(props, state)
    //    return props;
    // }
  

    render(){
        const tiles= this.props.items.map((curr, index)=>{
              return <Tiles key={index} obj={curr} index={index}/>
            });
        return(
            <div>
                <Grid>
                    <Row className="show-grid">
                    { this.props.items.length ? tiles : <div> LOADING.............</div> }
                    </Row>
                </Grid>
            </div>

        )
    }

}


const mapStateToProps = state => ({
    items: state.itemsReducer.items
  })
  const mapDispatchToProps = dispatch => bindActionCreators({
    getItems
  }, dispatch)



export default  connect(
    mapStateToProps,
    mapDispatchToProps
  )(SearchFormComponent)