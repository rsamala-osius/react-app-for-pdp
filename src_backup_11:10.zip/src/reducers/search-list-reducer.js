import GET_ITEMS  from '../constants';

const initialState = {
    items:[ ]  
 }

const itemsReducer = (state = initialState, action) => {
    if (action.type === GET_ITEMS) {
        return { items: action.data };
    }      
        
    return state
  }

  export default itemsReducer;
  
  