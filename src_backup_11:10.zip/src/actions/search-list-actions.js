import GET_ITEMS  from '../constants';
import {config} from '../config'

export const getItems = () => {
    return dispatch => {

        fetch(`${config.apiUrl}/products`)
            .then((resp) => resp.json()) // Transform the data into json
            .then(function(data) {
                dispatch({
                    type: GET_ITEMS,
                    data: data
                })
        })

        // setTimeout(() => {
        //     dispatch({
        //         type: GET_ITEMS,
        //         data: [
        //             {
        //                 "id": "4856268",
        //                 "productUrl": "https://www.macys.com/shop/product/via-spiga-faux-fur-collar-asymmetrical-coat?ID=4672331&CategoryID=269&swatchColor=Camel#fn=sp%3D1%26spc%3D1192%26ruleId%3D78%7CBOOST%20SAVED%20SET%7CBOOST%20ATTRIBUTE%26searchPass%3DmatchNone%26slotId%3D1",
        //                 "name": "Via Spiga Faux-Fur-Collar Asymmetrical Coat",
        //                 "brandname": "Via Spiga",
        //                 "productname": "Faux-Fur-Collar Asymmetrical Coat",
        //                 "brand": "Charter Club",
        //                 "primaryImage": "https://slimages.macysassets.com/is/image/MCY/products/4/optimized/3746404_fpx.tif?bgc=255,255,255&wid=224&qlt=90,0,0&layer=comp&op_sharpen=0&resMode=bicub&op_usm=0.7,1.0,0.5,0&fmt=jpeg",
        //                 "price": "80"
        //             }
        //         ]   
        //     })
        // }, 4000);
        
    }
  }