import { SET_SELECTED_PRODUCT } from '../../constants';

export const getItems = () => {
    return {
        
    }
  }