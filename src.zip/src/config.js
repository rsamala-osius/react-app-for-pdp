export const config = {
    // apiUrl: 'http://localhost:3004',
     apiUrl: 'http://localhost:8000',
}

